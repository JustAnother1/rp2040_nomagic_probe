/*
  automatically created hal/time_ms.h
  created at: 2025-03-17 01:14:53
  created from mbsp.json
*/

extern volatile uint32_t ms_since_boot;

